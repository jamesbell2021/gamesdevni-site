Drop your own Christmas .mp3 / .ogg / .m4a / .wav files in this folder.
If any are here, the TV plays them (shuffled) instead of the built-in music-box carols.
Press M on the TV page to mute, N for the next track.
Free old recordings: archive.org (search "Christmas carols public domain") or musopen.org.
