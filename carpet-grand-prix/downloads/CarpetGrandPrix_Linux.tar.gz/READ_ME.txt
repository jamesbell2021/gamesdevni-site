CARPET GRAND PRIX - a Christmas present from 3BL
=================================================

Slot-car racing on the living-room floor, Christmas morning 1986.
Up to four players. Your phones are the hand controllers.

1. Unzip this folder anywhere and run ./CarpetGrandPrix.x86_64
   (tar xzf the download first; it keeps the file runnable.)
   If you run a firewall, allow TCP ports 8765 and 8766 on your home
   network, or the phones will not be able to connect.
2. Everyone joins the home Wi-Fi (not the guest network) and scans the
   QR code on the screen. No app or account needed.
3. Hold POWER to go, let go for the bends. Too fast and you fly off!
   << and >> hop lanes to get past. Anyone can press Start the race.

No phone? The keyboard drives the red car: Up = power, Left/Right = lanes,
Space = start, L = laps, G = extra grip, M = carols on/off, F11 = full screen.
Phone can't connect? Press A on the lobby screen to try another address.

Happy Christmas from 3BL!   gamesdevni.site

Fonts: Racing Sans One, Press Start 2P and VT323, under the SIL Open Font
Licence (OFL_*.txt). Made with Godot Engine (godotengine.org/license).
